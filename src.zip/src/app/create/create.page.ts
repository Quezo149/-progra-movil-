import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-create',
  templateUrl: './create.page.html',
  styleUrls: ['./create.page.scss'],
  })
export class CreatePage{
  title: string = '';
  body: string = '';

  constructor(private apiService: ApiService, privatenavCtrl: NavController) {}
  

  ngOnInit() {
  }

}
