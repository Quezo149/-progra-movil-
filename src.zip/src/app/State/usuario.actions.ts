import { createAction, props } from '@ngrx/store';
import { Usuario } from 'src/app/Models/usuario.model';

export const setUsuario = createAction(
  '[Usuario] Set Usuario',
  props<{ usuario: Usuario }>()
);

export const clearUsuario = createAction('[Usuario] Clear Usuario');
