import { createReducer, on } from '@ngrx/store';
import { setUsuario } from './usuario.actions';
import { Usuario } from '../Models/usuario.model';

export interface State {
  usuario: Usuario | null;
  
}

export const initialState: State = {
  usuario: null,
  
};

const _usuarioReducer = createReducer(
  initialState,
  on(setUsuario, (state, { usuario }) => ({ ...state, usuario }))
);

export function usuarioReducer(state: any, action: any) {
  return _usuarioReducer(state, action);
}
