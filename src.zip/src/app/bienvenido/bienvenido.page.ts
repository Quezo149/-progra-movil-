import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Usuario } from 'src/app/Models/usuario.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bienvenido',
  templateUrl: './bienvenido.page.html',
  styleUrls: ['./bienvenido.page.scss'],
})
export class BienvenidoPage implements OnInit {
  usuario$: Observable<Usuario> | undefined;
  userName: string = '';
  userType: string = '';
  asist: string = '';

  constructor(
    private route: ActivatedRoute,
    private navCtrl: NavController,
    private store: Store<{ usuario: Usuario }>,
    private router: Router // Inyectamos Router
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.userName = params['userName'];
      this.userType = params['userType'];
      this.asist = params['asist'];
    });

    this.usuario$ = this.store.select('usuario');
  }

  goBack() {
    this.navCtrl.navigateBack('/home');
  }


  goToApiPage() {
    this.router.navigate(['/api']); 
  }
}





