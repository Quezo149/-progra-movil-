export interface Usuario {
    correo: string;
    tipo: string;
    asist: string ;
  }
  