import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { NavController } from '@ionic/angular';


@Component({
  selector: 'app-api',
  templateUrl: './api.page.html',
  
  styleUrls: ['./api.page.scss'],
})
export class APIPage implements OnInit {
  posts: any[] = [];
  selectedImage: string | null = null; // Variable para almacenar la imagen en base64

  constructor(
    private navCtrl: NavController,
    private apiService: ApiService) {}

  ngOnInit() {
    this.apiService.getPosts().subscribe((data: any) => {
      this.posts = data;
    });
  }
  goBack() {
    this.navCtrl.navigateBack('/bienvenido');
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.selectedImage = reader.result as string; // Convertir la imagen a base64
      };
      reader.readAsDataURL(file); // Leer el archivo y convertirlo
    }
  }
}
