import { Component } from '@angular/core';
import { AlertController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { setUsuario } from '../State/usuario.actions';
import { Usuario } from 'src/app/Models/usuario.model';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  email: string = '';
  pass: string = '';
  userType: string = '';
  errorMessage: string = '';
  asist: string = '';

  userValido1 = { email: 'fel.quezadar@duocuc.cl', pass: 'Pass123', asist:'90%'};
  userValido2 = { email: 'hola@duocuc.cl', pass: '12345678', asist:'100%'};

  constructor(
    private alertCtrl: AlertController,
    private router: Router,
    private loadingCtrl: LoadingController,
    private store: Store
  ) {this.userType = '';}

  async login() {
    if (this.email === '' || this.pass === '' || this.userType === '') {
      this.errorMessage = 'Por favor, ingrese todos los datos antes de iniciar sesión';
      return;
    }

    let asist = '';
    let mensajeBienvenida = '';

    if (
      this.email === this.userValido1.email &&
      this.pass === this.userValido1.pass &&
      this.userType === 'Alumno'
    ) {
      asist = '90%';
      mensajeBienvenida = 'Bienvenido Alumno';
    } else if (
      this.email === this.userValido2.email &&
      this.pass === this.userValido2.pass &&
      this.userType === 'Profesor'
    ) {
      asist = '100%';
      mensajeBienvenida = 'Bienvenido Profesor';
    } else {
      this.errorMessage = 'Correo, contraseña o tipo de usuario incorrectos';
      return;
    }

    const alert = await this.alertCtrl.create({
      header: 'Login exitoso',
      message: mensajeBienvenida,
      buttons: ['OK'],
    });
    await alert.present();

    const usuario: Usuario = {
      correo: this.email,
      tipo: this.userType,
      asist: this.asist
    };
    this.store.dispatch(setUsuario({ usuario }));

    const loading = await this.loadingCtrl.create({
      message: 'Cargando...',
      duration: 1000,
    });
    await loading.present();

    setTimeout(() => {
      this.router.navigate(['/bienvenido'], {
        queryParams: { 
          userType: this.userType, 
          asist: this.asist,
          userName: this.email.split('@')[0] },
      });
    }, 1000);
  }

  async goToForgotPass() {
    const loading = await this.loadingCtrl.create({
      message: 'Cargando...',
      duration: 3000,
    });
    await loading.present();

    setTimeout(() => {
      this.router.navigate(['/forgot-pass']);
    }, 3000);
  }
}
